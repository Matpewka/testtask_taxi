<?php

return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=localhost;dbname=testtask_taxi',
    'username' => 'root',
    'password' => '',
    'charset' => 'utf8',
];
