<?php

return [
    'adminEmail' => 'admin@example.com',

    'apiGoogleKey' => 'AIzaSyAbMMzjdC-VTNksE9cCfBfRAsWxOMEHiVE',
];
